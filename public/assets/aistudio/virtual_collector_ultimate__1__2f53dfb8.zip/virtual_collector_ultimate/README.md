# Virtual Collector Ultimate

Virtual Collector Ultimate records BetPawa Zambia Virtual League prices and result snapshots across every competition returned by the live round feed. It records five market groups, timestamps each capture in UTC, and keeps the data in a local SQLite database.

## Start

1. Unzip the app folder.
2. Install Python 3.9 or newer if it is not already available. The collector and odds-implied baseline need no additional packages.
3. For the optional machine-learning models, install the included requirements from this folder with `python -m pip install -r requirements.txt` (Windows: `py -3 -m pip install -r requirements.txt`).
4. Double-click `Start Windows.bat` on Windows or `Start Mac-Linux.command` on macOS/Linux.
5. The dashboard opens at `http://127.0.0.1:8766`.
6. Select **Start collecting**. The first capture starts immediately; later captures align to five-minute UTC boundaries.
7. Select **Stop** whenever you want to pause collection.

The app runs only on your computer and binds to `127.0.0.1`. It never places real bets and does not need your BetPawa password. Collection continues while the app window is running; closing its terminal stops collection. It uses port 8766 so it can run alongside the separate Roundroom app.

## Query And Export

Use the **From** and **Through** fields to search a time period. Times in the form use your computer's local time; each selected end minute is included. Choose a competition or leave the selection on **All leagues**. The dashboard refreshes the summary, price snapshots, result snapshots, and odds history for those filters.

The **Export CSV** links use the same selected time and competition filters. Open the resulting files in Excel or another spreadsheet program. All records remain in `data/virtual_collector_ultimate.sqlite3`; the database is not subject to the row limit of an Excel workbook.

Odds are recorded by capture timestamp. Results are stored both as the latest known result and as a time-stamped snapshot on each collection pass, so you can inspect how the feed reported a fixture during a chosen period.

## Updating An Existing Install

To keep your saved records, stop the old app and extract the updated files into the same app folder, replacing the program files but leaving the `data` folder untouched. If you extract into a new folder instead, copy the entire old `data` folder into that new folder before starting it. The AI tables are added when the updated app starts; the ZIP does not contain personal database files.

## AI Lab And Paper Account

Choose **AI Lab · Paper** in the collector header to open the local prediction and evaluation dashboard. The app adds its AI tables to the existing SQLite database without deleting collector history. It also saves one daily database backup in `data/backups/` and retains the newest 14 daily backups.

Predictions use complete 1X2 prices captured before kickoff and only results that were final before the prediction lock. The market-implied baseline is always available; logistic regression, random forest, extra trees, and gradient boosting require the optional dependencies above. Evaluation uses chronological walk-forward windows and a separate final test period. Install dependencies before launching the app to use those models.

Paper betting is virtual only. The default strategy is the market-implied baseline. You can change the virtual stake, probability threshold, exposure limit, and strategy in Paper Settings. Candidate models do not place paper bets unless explicitly allowed, and delayed or ambiguous scores remain unsettled. Starting bankroll is fixed after the first simulated bet so performance cannot be reset by changing it later.

Treat all model scores and paper returns as historical diagnostics, not a promise of predictive skill or future profit. The app initially predicts and settles full-time 1X2 only; collection of the other market groups is unchanged.

## Data Source

The collector reads BetPawa's currently accessible site data feed rather than clicking through the market tabs. This is not a documented public API; BetPawa could change or restrict it. The app displays collection errors in the dashboard. A five-minute cadence is the default. Historical prices and results are for analysis only and do not predict future outcomes.
