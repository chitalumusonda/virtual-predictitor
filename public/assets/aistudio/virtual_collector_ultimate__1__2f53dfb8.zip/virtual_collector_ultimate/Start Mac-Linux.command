#!/bin/sh
cd "$(dirname "$0")"
python3 app.py
status=$?
if [ "$status" -ne 0 ]; then
  printf "Virtual Collector Ultimate could not start. Check that Python 3 is installed.\n"
  printf "Press Return to close... "
  read -r _
fi
exit "$status"
