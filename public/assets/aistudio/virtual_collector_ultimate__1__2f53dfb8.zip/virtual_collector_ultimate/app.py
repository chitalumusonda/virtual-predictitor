import csv
import gzip
import io
import json
import sqlite3
import threading
import time
import urllib.request
import webbrowser
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from prediction_engine import PredictionService, initialize_ai_schema


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "virtual_collector_ultimate.sqlite3"
PAGE = ROOT / "index.html"
SITE = "https://www.betpawa.co.zm"
POLL_SECONDS = 300
BRAND_HEADERS = {
    "x-pawa-brand": "betpawa-zambia",
    "x-pawa-language": "en",
    "content-type": "application/x-protobuf",
    "accept": "application/json",
    "accept-encoding": "gzip",
    "user-agent": "Mozilla/5.0 VirtualCollectorUltimate/1.0",
}


def now_utc():
    return datetime.now(timezone.utc)


def stamp(value=None):
    return (value or now_utc()).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def parse_time(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def api_get(path):
    req = urllib.request.Request(SITE + path, headers=BRAND_HEADERS)
    with urllib.request.urlopen(req, timeout=20) as response:
        raw = response.read()
        if response.headers.get("Content-Encoding", "").lower() == "gzip":
            raw = gzip.decompress(raw)
        return json.loads(raw), len(raw)


def db_connect():
    conn = sqlite3.connect(DB_PATH, timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def ensure_database():
    DATA_DIR.mkdir(exist_ok=True)
    with db_connect() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS odds (
                id INTEGER PRIMARY KEY,
                captured_utc TEXT NOT NULL,
                season_id TEXT NOT NULL,
                matchday INTEGER NOT NULL,
                round_id TEXT NOT NULL,
                fixture_id TEXT NOT NULL,
                competition_id TEXT NOT NULL,
                competition TEXT NOT NULL,
                fixture TEXT NOT NULL,
                home TEXT NOT NULL,
                away TEXT NOT NULL,
                market TEXT NOT NULL,
                selection TEXT NOT NULL,
                odds REAL NOT NULL,
                probability REAL,
                kickoff_utc TEXT,
                UNIQUE(captured_utc, round_id, fixture_id, market, selection)
            );
            CREATE INDEX IF NOT EXISTS odds_time ON odds(captured_utc, competition_id);
            CREATE INDEX IF NOT EXISTS odds_history ON odds(round_id, fixture_id, market, selection, captured_utc);
            CREATE TABLE IF NOT EXISTS results (
                season_id TEXT NOT NULL,
                matchday INTEGER NOT NULL,
                round_id TEXT NOT NULL,
                fixture_id TEXT NOT NULL,
                competition_id TEXT NOT NULL,
                competition TEXT NOT NULL,
                fixture TEXT NOT NULL,
                home TEXT NOT NULL,
                away TEXT NOT NULL,
                ht_home INTEGER,
                ht_away INTEGER,
                ft_home INTEGER,
                ft_away INTEGER,
                outcome TEXT,
                total_goals INTEGER,
                btts TEXT,
                minute INTEGER,
                status TEXT NOT NULL,
                updated_utc TEXT NOT NULL,
                PRIMARY KEY(round_id, fixture_id)
            );
            CREATE INDEX IF NOT EXISTS results_status ON results(status, updated_utc);
            CREATE TABLE IF NOT EXISTS result_history (
                id INTEGER PRIMARY KEY,
                captured_utc TEXT NOT NULL,
                season_id TEXT NOT NULL,
                matchday INTEGER NOT NULL,
                round_id TEXT NOT NULL,
                fixture_id TEXT NOT NULL,
                competition_id TEXT NOT NULL,
                competition TEXT NOT NULL,
                fixture TEXT NOT NULL,
                home TEXT NOT NULL,
                away TEXT NOT NULL,
                ht_home INTEGER,
                ht_away INTEGER,
                ft_home INTEGER,
                ft_away INTEGER,
                outcome TEXT,
                total_goals INTEGER,
                btts TEXT,
                minute INTEGER,
                status TEXT NOT NULL,
                UNIQUE(captured_utc, round_id, fixture_id)
            );
            CREATE INDEX IF NOT EXISTS result_history_time ON result_history(captured_utc, competition_id);
            CREATE TABLE IF NOT EXISTS collection_log (
                id INTEGER PRIMARY KEY,
                captured_utc TEXT NOT NULL,
                season_id TEXT,
                matchday INTEGER,
                round_id TEXT,
                odds_rows INTEGER NOT NULL DEFAULT 0,
                result_rows INTEGER NOT NULL DEFAULT 0,
                bytes_received INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL,
                message TEXT NOT NULL
            );
        """)
        initialize_ai_schema(conn)


BACKUP_DIR = DATA_DIR / "backups"
BACKUP_LOCK = threading.Lock()


def backup_database():
    with BACKUP_LOCK:
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        target = BACKUP_DIR / f"virtual_collector_ultimate-{now_utc():%Y%m%d}.sqlite3"
        if target.exists():
            return
        source = db_connect()
        destination = sqlite3.connect(target)
        try:
            source.backup(destination)
        finally:
            destination.close()
            source.close()
        backups = sorted(BACKUP_DIR.glob("virtual_collector_ultimate-*.sqlite3"))
        for old in backups[:-14]:
            old.unlink(missing_ok=True)


def market_key(market):
    name = market.get("marketType", {}).get("displayName", "")
    ident = str(market.get("marketType", {}).get("id", ""))
    if ident == "3743" or name.startswith("1X2"):
        return "1X2"
    if ident == "5000" or "Over/Under" in name:
        return "O/U"
    if ident == "3795" or "Both Teams" in name:
        return "BTTS"
    if ident == "4693" or "Double Chance" in name:
        return "DC"
    if ident == "4706" or "Half Time/Full Time" in name or name == "HT / FT":
        return "HT/FT"
    return None


def result_values(event):
    result = event.get("results") or {}
    parts = result.get("participantPeriodResults") or []
    values = {"HOME": {}, "AWAY": {}}
    for participant in parts:
        side = participant.get("participant", {}).get("type")
        if side not in values:
            continue
        for item in participant.get("periodResults", []):
            period = item.get("period", {}).get("slug", "")
            if period == "FIRST_HALF":
                values[side]["ht"] = item.get("result")
            elif period == "FULL_TIME_EXCLUDING_OVERTIME":
                values[side]["ft"] = item.get("result")
    display = result.get("display") or {}
    try:
        minute = int(display.get("minute", 0))
    except (TypeError, ValueError):
        minute = 0
    period = (display.get("currentPeriod") or {}).get("slug", "")
    status = "FINAL" if minute >= 90 or "FULL_TIME" in period else "LIVE"
    return values, minute, status


class Collector:
    def __init__(self):
        self.lock = threading.Lock()
        self.capture_lock = threading.Lock()
        self.stop_event = threading.Event()
        self.running = False
        self.thread = None
        self.next_run_utc = None
        self.message = "Ready. Start collection to begin."

    def start(self):
        with self.lock:
            if self.running:
                return False
            self.running = True
            self.stop_event.clear()
            self.thread = threading.Thread(target=self._loop, daemon=True)
            self.thread.start()
            return True

    def stop(self):
        with self.lock:
            if not self.running:
                return False
            self.running = False
            self.next_run_utc = None
            self.stop_event.set()
            return True

    def capture_async(self):
        threading.Thread(target=self.capture_once, daemon=True).start()

    def _loop(self):
        while not self.stop_event.is_set():
            self.capture_once()
            if self.stop_event.is_set():
                break
            next_tick = (int(time.time() // POLL_SECONDS) + 1) * POLL_SECONDS
            self.next_run_utc = stamp(datetime.fromtimestamp(next_tick, timezone.utc))
            self.stop_event.wait(max(1, next_tick - time.time()))
        self.next_run_utc = None

    def _rounds(self, payload):
        rounds = []
        for season in payload.get("items", []):
            for rnd in season.get("rounds", []):
                trading = rnd.get("tradingTime") or {}
                if not trading.get("start") or not trading.get("end"):
                    continue
                rounds.append({
                    "season_id": str(season["id"]), "matchday": int(rnd["name"]),
                    "round_id": str(rnd["id"]), "start": parse_time(trading["start"]),
                    "end": parse_time(trading["end"]),
                })
        return rounds

    def _current_round(self, rounds, now):
        active = [r for r in rounds if r["start"] <= now < r["end"]]
        if active:
            return active[0]
        nearby = [r for r in rounds if r["start"] >= now and r["start"] - now <= timedelta(seconds=45)]
        return min(nearby, key=lambda r: r["start"]) if nearby else None

    def _store_result(self, conn, event, round_info, captured):
        participants = sorted(event.get("participants", []), key=lambda p: p.get("position", 0))
        if len(participants) < 2:
            return False
        home, away = participants[0].get("name", ""), participants[1].get("name", "")
        fixture = f"{home} - {away}"
        competition = event.get("competition") or {}
        competition_id = str(competition.get("id", "unknown"))
        competition_name = competition.get("name") or competition.get("displayName") or "Unknown League"
        values, minute, status = result_values(event) if event.get("results") else ({"HOME": {}, "AWAY": {}}, 0, "UPCOMING")
        ht_home, ht_away = values["HOME"].get("ht"), values["AWAY"].get("ht")
        ft_home, ft_away = values["HOME"].get("ft"), values["AWAY"].get("ft")
        ht_home = int(ht_home) if ht_home is not None else None
        ht_away = int(ht_away) if ht_away is not None else None
        ft_home = int(ft_home) if ft_home is not None else None
        ft_away = int(ft_away) if ft_away is not None else None
        if status == "FINAL" and ft_home is None and ft_away is None:
            return False
        outcome = "1" if ft_home is not None and ft_away is not None and ft_home > ft_away else "2" if ft_home is not None and ft_away is not None and ft_home < ft_away else "X" if ft_home is not None and ft_away is not None else None
        total = ft_home + ft_away if ft_home is not None and ft_away is not None else None
        btts = "Yes" if ft_home and ft_away else "No" if ft_home is not None and ft_away is not None else None
        fixture_id = str(event["id"])
        values = (round_info["season_id"], round_info["matchday"], round_info["round_id"], fixture_id,
                  competition_id, competition_name, fixture, home, away, ht_home, ht_away,
                  ft_home, ft_away, outcome, total, btts, minute, status)
        conn.execute("""
            INSERT INTO results
            (season_id,matchday,round_id,fixture_id,competition_id,competition,fixture,home,away,
             ht_home,ht_away,ft_home,ft_away,outcome,total_goals,btts,minute,status,updated_utc)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(round_id,fixture_id) DO UPDATE SET
              competition_id=excluded.competition_id, competition=excluded.competition,
              ht_home=excluded.ht_home, ht_away=excluded.ht_away, ft_home=excluded.ft_home,
              ft_away=excluded.ft_away, outcome=excluded.outcome, total_goals=excluded.total_goals,
              btts=excluded.btts, minute=excluded.minute,
              status=CASE WHEN results.status='FINAL' THEN 'FINAL' ELSE excluded.status END,
              updated_utc=excluded.updated_utc
        """, values + (captured,))
        conn.execute("""
            INSERT OR IGNORE INTO result_history
            (captured_utc,season_id,matchday,round_id,fixture_id,competition_id,competition,fixture,
             home,away,ht_home,ht_away,ft_home,ft_away,outcome,total_goals,btts,minute,status)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (captured,) + values)
        return status == "FINAL"

    def _store_odds(self, conn, payload, round_info, captured):
        count = 0
        for event in payload.get("responses", []):
            participants = sorted(event.get("participants", []), key=lambda p: p.get("position", 0))
            if len(participants) < 2:
                continue
            home, away = participants[0].get("name", ""), participants[1].get("name", "")
            fixture = f"{home} - {away}"
            competition = event.get("competition") or {}
            competition_id = str(competition.get("id", "unknown"))
            competition_name = competition.get("name") or competition.get("displayName") or "Unknown League"
            for market in event.get("markets", []):
                label = market_key(market)
                if not label:
                    continue
                for row in market.get("row", []):
                    for price in row.get("prices", []):
                        if price.get("suspended") or price.get("odds") is None:
                            continue
                        selection = price.get("name", "")
                        if label == "O/U":
                            handicap = price.get("handicap") or row.get("specifier", {}).get("total") or row.get("handicap")
                            if handicap:
                                selection = f"{selection} {handicap}"
                        probability = (price.get("probability") or {}).get("win")
                        conn.execute("""
                            INSERT OR IGNORE INTO odds
                            (captured_utc,season_id,matchday,round_id,fixture_id,competition_id,competition,
                             fixture,home,away,market,selection,odds,probability,kickoff_utc)
                            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                        """, (captured, round_info["season_id"], round_info["matchday"], round_info["round_id"],
                              str(event["id"]), competition_id, competition_name, fixture, home, away,
                              label, selection, float(price["odds"]), probability, event.get("startTime")))
                        count += 1
        return count

    def capture_once(self):
        if not self.capture_lock.acquire(blocking=False):
            return
        captured = stamp()
        season_id = matchday = round_id = None
        odds_count = result_count = bytes_received = 0
        status, message = "ERROR", "Capture failed"
        try:
            actual, n = api_get("/api/sportsbook/virtual/v2/seasons/list/actual")
            bytes_received += n
            rounds = self._rounds(actual)
            now = now_utc()
            current = self._current_round(rounds, now)
            with db_connect() as conn:
                pending_ids = {r[0] for r in conn.execute("SELECT DISTINCT round_id FROM results WHERE status!='FINAL'")}
            targets = [current] if current else []
            recent = [r for r in rounds if r["round_id"] in pending_ids and r["end"] <= now - timedelta(minutes=4) and now - r["end"] <= timedelta(minutes=25)]
            for rnd in sorted(recent, key=lambda r: r["end"], reverse=True)[:3]:
                if not current or rnd["round_id"] != current["round_id"]:
                    targets.append(rnd)
            if not targets:
                raise RuntimeError("No active round window was returned. Try again near a five-minute round boundary.")
            with db_connect() as conn:
                for rnd in targets:
                    payload, n = api_get(f"/api/sportsbook/virtual/v3/events/list/by-round/{rnd['round_id']}")
                    bytes_received += n
                    if current and rnd["round_id"] == current["round_id"]:
                        odds_count += self._store_odds(conn, payload, rnd, captured)
                    for event in payload.get("responses", []):
                        if self._store_result(conn, event, rnd, captured):
                            result_count += 1
                    if current and rnd["round_id"] == current["round_id"]:
                        season_id, matchday, round_id = rnd["season_id"], rnd["matchday"], rnd["round_id"]
                status = "OK"
                message = f"Saved {odds_count:,} open odds rows and refreshed {result_count:,} final results across all leagues."
                if current and odds_count == 0:
                    message = "Round feed loaded across all leagues, but no open prices were available."
                conn.execute("""
                    INSERT INTO collection_log(captured_utc,season_id,matchday,round_id,odds_rows,result_rows,bytes_received,status,message)
                    VALUES(?,?,?,?,?,?,?,?,?)
                """, (captured, season_id, matchday, round_id, odds_count, result_count, bytes_received, status, message))
            self.message = message
            try:
                PREDICTION_ENGINE.notify()
                threading.Thread(target=backup_database, name="daily-db-backup", daemon=True).start()
            except Exception as exc:
                self.message += f" Backup/prediction notification issue: {str(exc)[:120]}"
        except Exception as exc:
            self.message = str(exc)[:350]
            with db_connect() as conn:
                conn.execute("""
                    INSERT INTO collection_log(captured_utc,season_id,matchday,round_id,odds_rows,result_rows,bytes_received,status,message)
                    VALUES(?,?,?,?,?,?,?,?,?)
                """, (captured, season_id, matchday, round_id, odds_count, result_count, bytes_received, status, self.message))
        finally:
            self.capture_lock.release()

    def state(self, filters):
        where, params = make_filter("captured_utc", filters)
        with db_connect() as conn:
            total_odds = conn.execute("SELECT COUNT(*) FROM odds").fetchone()[0]
            total_results = conn.execute("SELECT COUNT(*) FROM result_history").fetchone()[0]
            total_snapshots = conn.execute("SELECT COUNT(DISTINCT captured_utc || ':' || round_id) FROM odds").fetchone()[0]
            odds_count = conn.execute(f"SELECT COUNT(*) FROM odds WHERE {where}", params).fetchone()[0]
            results_count = conn.execute(f"SELECT COUNT(*) FROM result_history WHERE {where}", params).fetchone()[0]
            snapshots = conn.execute(f"SELECT COUNT(DISTINCT captured_utc || ':' || round_id) FROM odds WHERE {where}", params).fetchone()[0]
            latest = conn.execute(f"SELECT season_id,matchday,round_id,MAX(captured_utc) AS captured_utc FROM odds WHERE {where} GROUP BY season_id,matchday,round_id ORDER BY captured_utc DESC LIMIT 1", params).fetchone()
            odds = []
            if latest:
                odds = [dict(r) for r in conn.execute(f"""
                    SELECT fixture,home,away,competition_id,competition,market,selection,odds,probability,
                           captured_utc,season_id,matchday,round_id
                    FROM odds WHERE {where} AND captured_utc=? AND round_id=? ORDER BY competition,fixture,market,selection
                """, params + [latest["captured_utc"], latest["round_id"]])]
            recent = [dict(r) for r in conn.execute(f"""
                SELECT captured_utc,season_id,matchday,round_id,fixture,competition_id,competition,
                       market,selection,odds,probability
                FROM odds WHERE {where} ORDER BY captured_utc DESC,id DESC LIMIT 240
            """, params)]
            results = []
            for row in conn.execute(f"""
                SELECT captured_utc,fixture,competition_id,competition,matchday,ht_home,ht_away,
                       ft_home,ft_away,status,minute FROM result_history WHERE {where}
                ORDER BY captured_utc DESC,id DESC LIMIT 160
            """, params):
                item = dict(row)
                item["score"] = f"{item['ft_home']} - {item['ft_away']}" if item["ft_home"] is not None and item["ft_away"] is not None else None
                results.append(item)
            leagues = [dict(r) for r in conn.execute("SELECT DISTINCT competition_id,competition FROM odds ORDER BY competition")]
            last = conn.execute("SELECT captured_utc,status,message FROM collection_log ORDER BY id DESC LIMIT 1").fetchone()
        return {
            "running": self.running, "next_run_utc": self.next_run_utc, "message": self.message,
            "last_run": dict(last) if last else None,
            "counts": {"odds": odds_count, "results": results_count, "snapshots": snapshots},
            "all_counts": {"odds": total_odds, "results": total_results, "snapshots": total_snapshots},
            "latest": dict(latest) if latest else None, "odds": odds, "recent": recent,
            "results_rows": results, "leagues": leagues,
        }


def make_filter(column, filters):
    clauses, params = [], []
    if filters.get("from"):
        clauses.append(f"{column} >= ?")
        params.append(filters["from"])
    if filters.get("to"):
        clauses.append(f"{column} <= ?")
        params.append(filters["to"])
    if filters.get("competition"):
        clauses.append("competition_id = ?")
        params.append(filters["competition"])
    return " AND ".join(clauses) or "1=1", params


def parse_filters(query):
    filters = {key: query.get(key, [""])[0] for key in ("from", "to", "competition")}
    for key in ("from", "to"):
        if filters[key]:
            filters[key] = stamp(parse_time(filters[key]).astimezone(timezone.utc))
    if filters["from"] and filters["to"] and filters["from"] > filters["to"]:
        raise ValueError("Start time must be earlier than end time.")
    return filters


COLLECTOR = Collector()
PREDICTION_ENGINE = PredictionService(db_connect)


class Handler(BaseHTTPRequestHandler):
    def send_json(self, payload, code=200):
        raw = json.dumps(payload, separators=(",", ":")).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        if parsed.path == "/ai" or parsed.path == "/ai/":
            raw = (ROOT / "ai_dashboard.html").read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
            return
        if parsed.path == "/api/ai/state":
            payload = PREDICTION_ENGINE.state()
            payload["collector"]["running"] = COLLECTOR.running
            payload["collector"]["next_run_utc"] = COLLECTOR.next_run_utc
            payload["collector"]["message"] = COLLECTOR.message
            self.send_json(payload)
            return
        try:
            filters = parse_filters(query)
            if parsed.path == "/api/state":
                self.send_json(COLLECTOR.state(filters))
                return
            if parsed.path in ("/api/export/odds.csv", "/api/export/results.csv"):
                self.export_csv(parsed.path.endswith("results.csv"), filters)
                return
        except (ValueError, TypeError) as exc:
            self.send_json({"error": str(exc)}, 400)
            return
        if parsed.path == "/" or parsed.path == "/index.html":
            raw = PAGE.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
            return
        self.send_error(404)

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            length = min(int(self.headers.get("Content-Length", "0")), 4096)
            payload = json.loads(self.rfile.read(length) or b"{}")
            if path == "/api/control":
                action = payload.get("action")
                if action == "start":
                    changed = COLLECTOR.start()
                    self.send_json({"message": "Collection started. First capture is running now." if changed else "Collection is already running."}, 202)
                elif action == "stop":
                    changed = COLLECTOR.stop()
                    self.send_json({"message": "Collection stopped." if changed else "Collection is already paused."})
                elif action == "capture":
                    COLLECTOR.capture_async()
                    self.send_json({"message": "Capture requested."}, 202)
                else:
                    self.send_json({"error": "Choose start, stop, or capture."}, 400)
            elif path == "/api/ai/settings":
                settings = PREDICTION_ENGINE.save_settings(payload)
                self.send_json({"message": "Paper account settings saved.", "settings": settings})
            elif path == "/api/ai/backtest":
                started = PREDICTION_ENGINE.start_backtest()
                self.send_json({"message": "Chronological evaluation started." if started else "An evaluation is already running."}, 202)
            elif path == "/api/ai/model-action":
                PREDICTION_ENGINE.reinstate_model(payload.get("model_id", ""), payload.get("reason", ""))
                self.send_json({"message": "Model reinstated after documented reevaluation."})
            else:
                self.send_error(404)
        except Exception as exc:
            self.send_json({"error": str(exc)[:200]}, 400)

    def export_csv(self, results, filters):
        if results:
            table, time_column = "result_history", "captured_utc"
            filename = "virtual_collector_ultimate_results.csv"
        else:
            table, time_column = "odds", "captured_utc"
            filename = "virtual_collector_ultimate_odds.csv"
        where, params = make_filter(time_column, filters)
        with db_connect() as conn:
            rows = conn.execute(f"SELECT * FROM {table} WHERE {where} ORDER BY captured_utc DESC,id DESC", params).fetchall()
        output = io.StringIO()
        writer = csv.writer(output)
        if rows:
            writer.writerow(rows[0].keys())
            writer.writerows([tuple(row) for row in rows])
        else:
            writer.writerow(["No rows matched the selected filters"])
        raw = output.getvalue().encode("utf-8-sig")
        self.send_response(200)
        self.send_header("Content-Type", "text/csv; charset=utf-8")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def log_message(self, fmt, *args):
        print(f"[{self.log_date_time_string()}] {fmt % args}")


def main():
    ensure_database()
    backup_database()
    PREDICTION_ENGINE.start()
    host, port = "127.0.0.1", 8766
    server = ThreadingHTTPServer((host, port), Handler)
    url = f"http://{host}:{port}"
    print("Virtual Collector Ultimate is running locally.")
    print("Use the dashboard to start or stop five-minute all-league captures.")
    print(f"Data stays in: {DB_PATH}")
    print(f"Open: {url}")
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        COLLECTOR.stop()
        PREDICTION_ENGINE.stop()
        server.server_close()


if __name__ == "__main__":
    main()
