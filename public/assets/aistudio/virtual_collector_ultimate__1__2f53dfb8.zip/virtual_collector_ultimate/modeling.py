import math
import random
from collections import Counter


CLASSES = ("1", "X", "2")
MIN_MODEL_TRAINING = 40
MODEL_INFO = {
    "market_implied": ("Market-implied baseline", "1.0.0", "BASELINE"),
    "majority": ("Majority-class baseline", "1.0.0", "CANDIDATE"),
    "logistic_regression": ("Logistic regression", "1.0.0", "CANDIDATE"),
    "random_forest": ("Random forest", "1.0.0", "CANDIDATE"),
    "extra_trees": ("Extra trees", "1.0.0", "CANDIDATE"),
    "gradient_boosting": ("Gradient boosting", "1.0.0", "CANDIDATE"),
}


def odds_features(home, draw, away):
    odds = (float(home), float(draw), float(away))
    if any(value <= 1 for value in odds):
        raise ValueError("Decimal odds must be greater than 1.")
    raw = [1 / value for value in odds]
    total = sum(raw)
    fair = [value / total for value in raw]
    ordered = sorted(fair, reverse=True)
    return fair, [*fair, total - 1, ordered[0], ordered[0] - ordered[1]]


def normalized_probabilities(values):
    clipped = [max(1e-12, min(1.0, float(value))) for value in values]
    total = sum(clipped)
    return [value / total for value in clipped]


def _new_estimator(model_id):
    from sklearn.ensemble import ExtraTreesClassifier, GradientBoostingClassifier, RandomForestClassifier
    from sklearn.linear_model import LogisticRegression

    if model_id == "logistic_regression":
        return LogisticRegression(C=0.5, max_iter=1000, random_state=7)
    if model_id == "random_forest":
        return RandomForestClassifier(n_estimators=120, max_depth=5, min_samples_leaf=4, random_state=7, n_jobs=1)
    if model_id == "extra_trees":
        return ExtraTreesClassifier(n_estimators=120, max_depth=5, min_samples_leaf=4, random_state=7, n_jobs=1)
    if model_id == "gradient_boosting":
        return GradientBoostingClassifier(n_estimators=80, max_depth=2, learning_rate=0.05, random_state=7)
    raise ValueError(f"Unknown model: {model_id}")


def predict_many(model_id, training, targets):
    """Fit only on the supplied historical rows and return fixed 1/X/2 columns."""
    if model_id == "market_implied":
        return [normalized_probabilities(row["features"][:3]) for row in targets], "READY"
    if model_id == "majority":
        labels = [row["outcome"] for row in training]
        counts = Counter(labels)
        denominator = len(labels) + len(CLASSES)
        prior = [(counts.get(label, 0) + 1) / denominator for label in CLASSES]
        return [prior[:] for _ in targets], "READY"
    if len(training) < MIN_MODEL_TRAINING:
        return [None for _ in targets], "INSUFFICIENT_TRAINING"
    if len({row["outcome"] for row in training}) < 2:
        return [None for _ in targets], "INSUFFICIENT_CLASSES"
    try:
        estimator = _new_estimator(model_id)
    except ImportError:
        return [None for _ in targets], "DEPENDENCY_MISSING"
    try:
        estimator.fit([row["features"] for row in training], [row["outcome"] for row in training])
        class_indexes = {label: i for i, label in enumerate(estimator.classes_)}
        output = []
        for row in targets:
            raw = estimator.predict_proba([row["features"]])[0]
            output.append(normalized_probabilities([raw[class_indexes[label]] if label in class_indexes else 0 for label in CLASSES]))
        return output, "READY"
    except Exception as exc:
        return [None for _ in targets], f"MODEL_ERROR: {type(exc).__name__}: {exc}"[:180]


def _wilson(successes, total, z=1.959963984540054):
    if total == 0:
        return None, None
    p = successes / total
    denominator = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denominator
    margin = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denominator
    return max(0.0, center - margin), min(1.0, center + margin)


def _mean_interval(values, seed=11, repeats=350):
    if not values:
        return None, None
    if len(values) == 1:
        return values[0], values[0]
    rng = random.Random(seed)
    means = []
    for _ in range(repeats):
        means.append(sum(values[rng.randrange(len(values))] for _ in values) / len(values))
    means.sort()
    return means[int(0.025 * (repeats - 1))], means[int(0.975 * (repeats - 1))]


wilson_interval = _wilson
bootstrap_mean_interval = _mean_interval


def _calibration(actuals, probabilities, buckets=5):
    rows = []
    scored = []
    for actual, probability in zip(actuals, probabilities):
        predicted = max(range(len(CLASSES)), key=lambda i: probability[i])
        scored.append((max(probability), CLASSES[predicted] == actual))
    for index in range(buckets):
        low, high = index / buckets, (index + 1) / buckets
        group = [item for item in scored if low <= item[0] < high or (index == buckets - 1 and item[0] == 1)]
        if group:
            rows.append({"lower": low, "upper": high, "n": len(group),
                         "mean_probability": sum(x[0] for x in group) / len(group),
                         "accuracy": sum(x[1] for x in group) / len(group)})
    return rows


def simulate_bets(rows, probabilities, settings):
    start = float(settings["starting_bankroll"])
    cash = start
    topups = 0.0
    stakes = 0.0
    gross_payouts = 0.0
    profit = 0.0
    wins = bets = 0
    unit_returns = []
    exposure = Counter()
    peak = start
    drawdown = 0.0
    threshold = float(settings["minimum_probability"])
    unit_stake = min(float(settings["stake"]), float(settings["maximum_stake"]))
    exposure_limit = float(settings["maximum_round_exposure"])
    topup_amount = float(settings["topup_amount"])
    for row, probability in zip(rows, probabilities):
        if not probability:
            continue
        choice = max(range(3), key=lambda i: probability[i])
        confidence = probability[choice]
        if confidence < threshold or exposure[row["round_id"]] + unit_stake > exposure_limit:
            continue
        stake = unit_stake
        while cash < stake and topup_amount > 0:
            cash += topup_amount
            topups += topup_amount
        if cash < stake:
            continue
        odds = float(row["odds"][CLASSES[choice]])
        cash -= stake
        stakes += stake
        exposure[row["round_id"]] += stake
        bets += 1
        won = row["outcome"] == CLASSES[choice]
        if won:
            payout = stake * odds
            cash += payout
            gross_payouts += payout
            profit += payout - stake
            wins += 1
            unit_returns.append(odds - 1)
        else:
            profit -= stake
            unit_returns.append(-1.0)
        equity = start + profit
        peak = max(peak, equity)
        drawdown = max(drawdown, peak - equity)
    roi_low, roi_high = _mean_interval(unit_returns, seed=19)
    return {
        "bet_count": bets, "bet_wins": wins, "win_rate": wins / bets if bets else None,
        "win_rate_low": _wilson(wins, bets)[0], "win_rate_high": _wilson(wins, bets)[1],
        "stakes": stakes, "gross_payouts": gross_payouts, "profit": profit,
        "roi_stake": profit / stakes if stakes else None,
        "roi_starting_capital": profit / start if start else None,
        "roi_stake_low": roi_low, "roi_stake_high": roi_high,
        "roi_starting_low": roi_low * stakes / start if roi_low is not None and start else None,
        "roi_starting_high": roi_high * stakes / start if roi_high is not None and start else None,
        "topups": topups, "max_drawdown": drawdown,
        "max_drawdown_pct": drawdown / peak if peak else None,
    }


def score_predictions(actuals, probabilities, rows, settings):
    count = len(actuals)
    if count == 0 or any(probability is None for probability in probabilities):
        return {"sample_size": count, "status": "INSUFFICIENT_DATA"}
    normalized = [normalized_probabilities(p) for p in probabilities]
    indexes = {label: i for i, label in enumerate(CLASSES)}
    predicted = [CLASSES[max(range(3), key=lambda i: p[i])] for p in normalized]
    correct = sum(a == p for a, p in zip(actuals, predicted))
    recalls = []
    matrix = {actual: {label: 0 for label in CLASSES} for actual in CLASSES}
    log_losses, briers = [], []
    for actual, guess, probability in zip(actuals, predicted, normalized):
        matrix[actual][guess] += 1
        actual_index = indexes[actual]
        log_losses.append(-math.log(max(1e-12, probability[actual_index])))
        briers.append(sum((probability[i] - (1 if i == actual_index else 0)) ** 2 for i in range(3)))
    for actual in CLASSES:
        total = sum(matrix[actual].values())
        if total:
            recalls.append(matrix[actual][actual] / total)
    accuracy_low, accuracy_high = _wilson(correct, count)
    loss_low, loss_high = _mean_interval(log_losses)
    brier_low, brier_high = _mean_interval(briers, seed=13)
    financial = simulate_bets(rows, normalized, settings)
    return {
        "status": "EVALUATED", "sample_size": count, "accuracy": correct / count,
        "accuracy_low": accuracy_low, "accuracy_high": accuracy_high,
        "balanced_accuracy": sum(recalls) / len(recalls) if recalls else None,
        "log_loss": sum(log_losses) / count, "log_loss_low": loss_low, "log_loss_high": loss_high,
        "brier_score": sum(briers) / count, "brier_low": brier_low, "brier_high": brier_high,
        "confusion": matrix, "calibration": _calibration(actuals, normalized), **financial,
    }


def loss_advantage_interval(actuals, model_probabilities, baseline_probabilities, seed=31, repeats=500):
    if len(actuals) < 2:
        return None, None
    class_index = {label: i for i, label in enumerate(CLASSES)}
    delta = []
    for label, model, baseline in zip(actuals, model_probabilities, baseline_probabilities):
        index = class_index[label]
        delta.append(math.log(max(1e-12, baseline[index])) - math.log(max(1e-12, model[index])))
    return _mean_interval(delta, seed=seed, repeats=repeats)


def randomness_summary(rows):
    counts = Counter(row["outcome"] for row in rows)
    total = sum(counts.values())
    if total < 2:
        return {"n": total, "outcomes": dict(counts), "chi_square": None, "uniform_p_value": None, "home_win_runs_p_value": None}
    expected = total / 3
    chi_square = sum((counts.get(label, 0) - expected) ** 2 / expected for label in CLASSES)
    uniform_p = math.exp(-chi_square / 2)
    binary = [row["outcome"] == "1" for row in rows]
    n1 = sum(binary)
    n0 = total - n1
    runs = 1 + sum(binary[i] != binary[i - 1] for i in range(1, total))
    if n0 == 0 or n1 == 0 or total < 3:
        runs_p = None
    else:
        mean = 1 + 2 * n0 * n1 / total
        variance = 2 * n0 * n1 * (2 * n0 * n1 - total) / (total * total * (total - 1))
        z = (abs(runs - mean) - 0.5) / math.sqrt(variance) if variance > 0 else 0
        runs_p = math.erfc(max(0, z) / math.sqrt(2))
    return {"n": total, "outcomes": {label: counts.get(label, 0) for label in CLASSES},
            "chi_square": chi_square, "uniform_p_value": uniform_p,
            "home_win_runs_p_value": runs_p}


def evaluate_chronologically(model_id, dataset, settings):
    """Expanding-window folds plus a final chronological holdout; no random split."""
    count = len(dataset)
    if count < 20:
        return [], "INSUFFICIENT_HISTORY"
    holdout_start = max(1, int(count * 0.8))
    development = dataset[:holdout_start]
    final_test = dataset[holdout_start:]
    windows = []
    if len(development) >= 80:
        initial_train = max(40, len(development) // 2)
        remaining = len(development) - initial_train
        fold_size = max(1, remaining // 4)
        for fold in range(4):
            start = initial_train + fold * fold_size
            end = len(development) if fold == 3 else min(len(development), start + fold_size)
            if end <= start:
                continue
            train, test = development[:start], development[start:end]
            probs, status = predict_many(model_id, train, test)
            scored = score_predictions([row["outcome"] for row in test], probs, test, settings) if status == "READY" else {"status": status, "sample_size": len(test)}
            windows.append({"window": f"walk_forward_{fold + 1}", "training_n": len(train), "test_n": len(test), **scored})
    if final_test:
        probs, status = predict_many(model_id, development, final_test)
        scored = score_predictions([row["outcome"] for row in final_test], probs, final_test, settings) if status == "READY" else {"status": status, "sample_size": len(final_test)}
        windows.append({"window": "final_untouched", "training_n": len(development), "test_n": len(final_test), **scored})
    return windows, "EVALUATED" if any(row.get("status") == "EVALUATED" for row in windows) else "INSUFFICIENT_HISTORY"
