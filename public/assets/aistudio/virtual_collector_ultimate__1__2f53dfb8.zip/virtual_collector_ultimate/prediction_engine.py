import hashlib
import importlib.util
import json
import math
import queue
import sqlite3
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone

from modeling import CLASSES, MODEL_INFO, _mean_interval, _wilson, evaluate_chronologically, odds_features, predict_many, randomness_summary


DEFAULT_SETTINGS = {
    "starting_bankroll": 1000.0,
    "stake": 10.0,
    "maximum_stake": 10.0,
    "minimum_probability": 0.45,
    "maximum_round_exposure": 50.0,
    "topup_amount": 500.0,
    "automatic_topups": True,
    "auto_paper_bets": True,
    "active_model": "market_implied",
    "allow_unqualified_paper": False,
    "qualification_min_test": 100,
    "qualification_min_bets": 100,
}


def now_utc():
    return datetime.now(timezone.utc)


def stamp(value=None):
    return (value or now_utc()).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def parse_time(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def initialize_ai_schema(conn):
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS ai_settings (
            key TEXT PRIMARY KEY,
            value_json TEXT NOT NULL,
            updated_utc TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS model_registry (
            model_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            version TEXT NOT NULL,
            status TEXT NOT NULL,
            status_reason TEXT NOT NULL DEFAULT '',
            bad_evaluations INTEGER NOT NULL DEFAULT 0,
            updated_utc TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS model_status_history (
            id INTEGER PRIMARY KEY,
            model_id TEXT NOT NULL,
            previous_status TEXT,
            new_status TEXT NOT NULL,
            reason TEXT NOT NULL,
            changed_utc TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS prediction_inputs (
            id INTEGER PRIMARY KEY,
            round_id TEXT NOT NULL,
            fixture_id TEXT NOT NULL,
            competition_id TEXT NOT NULL,
            competition TEXT NOT NULL,
            fixture TEXT NOT NULL,
            locked_captured_utc TEXT NOT NULL,
            kickoff_utc TEXT NOT NULL,
            odds_home REAL NOT NULL,
            odds_draw REAL NOT NULL,
            odds_away REAL NOT NULL,
            features_json TEXT NOT NULL,
            source_hash TEXT NOT NULL,
            created_utc TEXT NOT NULL,
            UNIQUE(round_id, fixture_id)
        );
        CREATE INDEX IF NOT EXISTS prediction_inputs_time ON prediction_inputs(locked_captured_utc, kickoff_utc);
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY,
            input_id INTEGER NOT NULL REFERENCES prediction_inputs(id),
            model_id TEXT NOT NULL REFERENCES model_registry(model_id),
            model_version TEXT NOT NULL,
            predicted_utc TEXT NOT NULL,
            training_observations INTEGER NOT NULL,
            status TEXT NOT NULL,
            predicted_selection TEXT,
            probabilities_json TEXT,
            UNIQUE(input_id, model_id)
        );
        CREATE INDEX IF NOT EXISTS predictions_time ON predictions(predicted_utc, model_id);
        CREATE TABLE IF NOT EXISTS prediction_scores (
            prediction_id INTEGER PRIMARY KEY REFERENCES predictions(id),
            actual_outcome TEXT NOT NULL,
            scored_utc TEXT NOT NULL,
            correct INTEGER NOT NULL,
            log_loss REAL NOT NULL,
            brier_score REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS paper_bets (
            id INTEGER PRIMARY KEY,
            input_id INTEGER NOT NULL UNIQUE REFERENCES prediction_inputs(id),
            prediction_id INTEGER NOT NULL REFERENCES predictions(id),
            round_id TEXT NOT NULL,
            fixture_id TEXT NOT NULL,
            model_id TEXT NOT NULL,
            model_version TEXT NOT NULL,
            market TEXT NOT NULL,
            selection TEXT NOT NULL,
            locked_captured_utc TEXT NOT NULL,
            odds REAL NOT NULL,
            confidence REAL NOT NULL,
            stake REAL NOT NULL,
            status TEXT NOT NULL,
            placed_utc TEXT NOT NULL,
            settled_utc TEXT,
            actual_outcome TEXT,
            gross_payout REAL NOT NULL DEFAULT 0,
            net_profit REAL,
            bankroll_after REAL
        );
        CREATE INDEX IF NOT EXISTS paper_bets_status ON paper_bets(status, placed_utc);
        CREATE TABLE IF NOT EXISTS paper_ledger (
            id INTEGER PRIMARY KEY,
            created_utc TEXT NOT NULL,
            transaction_type TEXT NOT NULL,
            amount REAL NOT NULL,
            bet_id INTEGER REFERENCES paper_bets(id),
            reference_key TEXT NOT NULL UNIQUE,
            note TEXT NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS paper_ledger_time ON paper_ledger(created_utc, transaction_type);
        CREATE TABLE IF NOT EXISTS evaluation_runs (
            id TEXT PRIMARY KEY,
            started_utc TEXT NOT NULL,
            completed_utc TEXT,
            status TEXT NOT NULL,
            message TEXT NOT NULL,
            dataset_size INTEGER NOT NULL DEFAULT 0,
            cutoff_utc TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS evaluation_metrics (
            run_id TEXT NOT NULL REFERENCES evaluation_runs(id),
            model_id TEXT NOT NULL,
            window_name TEXT NOT NULL,
            training_n INTEGER NOT NULL,
            test_n INTEGER NOT NULL,
            status TEXT NOT NULL,
            accuracy REAL,
            accuracy_low REAL,
            accuracy_high REAL,
            balanced_accuracy REAL,
            log_loss REAL,
            log_loss_low REAL,
            log_loss_high REAL,
            brier_score REAL,
            brier_low REAL,
            brier_high REAL,
            confusion_json TEXT,
            calibration_json TEXT,
            bet_count INTEGER NOT NULL DEFAULT 0,
            bet_wins INTEGER NOT NULL DEFAULT 0,
            win_rate REAL,
            win_rate_low REAL,
            win_rate_high REAL,
            profit REAL,
            roi_stake REAL,
            roi_stake_low REAL,
            roi_stake_high REAL,
            roi_starting_capital REAL,
            roi_starting_low REAL,
            roi_starting_high REAL,
            max_drawdown REAL,
            max_drawdown_pct REAL,
            loss_advantage_low REAL,
            loss_advantage_high REAL,
            qualification TEXT NOT NULL DEFAULT 'NOT_EVALUATED',
            PRIMARY KEY(run_id, model_id, window_name)
        );
        CREATE TABLE IF NOT EXISTS ai_events (
            id INTEGER PRIMARY KEY,
            created_utc TEXT NOT NULL,
            severity TEXT NOT NULL,
            category TEXT NOT NULL,
            message TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS ai_events_time ON ai_events(created_utc DESC);
    """)
    metric_columns = {row["name"] for row in conn.execute("PRAGMA table_info(evaluation_metrics)")}
    for column in ("win_rate_low", "win_rate_high", "roi_stake_low", "roi_stake_high", "roi_starting_low", "roi_starting_high"):
        if column not in metric_columns:
            conn.execute(f"ALTER TABLE evaluation_metrics ADD COLUMN {column} REAL")
    current = stamp()
    for key, value in DEFAULT_SETTINGS.items():
        conn.execute("INSERT OR IGNORE INTO ai_settings(key,value_json,updated_utc) VALUES(?,?,?)",
                     (key, json.dumps(value), current))
    for model_id, (name, version, status) in MODEL_INFO.items():
        conn.execute("INSERT OR IGNORE INTO model_registry(model_id,name,version,status,updated_utc) VALUES(?,?,?,?,?)",
                     (model_id, name, version, status, current))


def _settings(conn):
    values = dict(DEFAULT_SETTINGS)
    for row in conn.execute("SELECT key,value_json FROM ai_settings"):
        try:
            values[row["key"]] = json.loads(row["value_json"])
        except (TypeError, ValueError):
            continue
    return values


def _event(conn, severity, category, message):
    conn.execute("INSERT INTO ai_events(created_utc,severity,category,message) VALUES(?,?,?,?)",
                 (stamp(), severity, category, str(message)[:500]))


def _odds_cte(min_capture=False):
    recent_clause = "AND julianday(captured_utc)>=julianday(?)" if min_capture else ""
    return """
        WITH complete_snapshots AS (
            SELECT round_id,fixture_id,captured_utc,
                   MIN(kickoff_utc) AS kickoff_utc,
                   MAX(season_id) AS season_id,MAX(matchday) AS matchday,
                   MAX(competition_id) AS competition_id,MAX(competition) AS competition,
                   MAX(fixture) AS fixture,
                   MAX(CASE WHEN selection='1' THEN odds END) AS odds_home,
                   MAX(CASE WHEN selection='X' THEN odds END) AS odds_draw,
                   MAX(CASE WHEN selection='2' THEN odds END) AS odds_away
            FROM odds
            WHERE market='1X2' """ + recent_clause + """
            GROUP BY round_id,fixture_id,captured_utc
            HAVING COUNT(DISTINCT CASE WHEN selection IN ('1','X','2') THEN selection END)=3
        ),
        ranked_snapshots AS (
            SELECT *,ROW_NUMBER() OVER(PARTITION BY round_id,fixture_id ORDER BY julianday(captured_utc)) AS sequence_no
            FROM complete_snapshots
            WHERE kickoff_utc IS NOT NULL AND julianday(captured_utc)<julianday(kickoff_utc)
        )
    """


def completed_dataset(conn, cutoff_utc=None):
    cutoff = cutoff_utc or stamp()
    sql = _odds_cte() + """
        SELECT r.round_id,r.fixture_id,r.competition,r.fixture,r.outcome,r.updated_utc,
               s.kickoff_utc,s.odds_home,s.odds_draw,s.odds_away
        FROM results r
        JOIN ranked_snapshots s ON s.round_id=r.round_id AND s.fixture_id=r.fixture_id AND s.sequence_no=1
        WHERE r.status='FINAL' AND r.outcome IN ('1','X','2')
          AND r.ft_home IS NOT NULL AND r.ft_away IS NOT NULL
          AND julianday(r.updated_utc)<julianday(?)
        ORDER BY julianday(s.kickoff_utc),r.round_id,r.fixture_id
    """
    rows = []
    for record in conn.execute(sql, (cutoff,)):
        try:
            fair, features = odds_features(record["odds_home"], record["odds_draw"], record["odds_away"])
        except (TypeError, ValueError, ZeroDivisionError):
            continue
        rows.append({
            "round_id": record["round_id"], "fixture_id": record["fixture_id"],
            "competition": record["competition"], "fixture": record["fixture"],
            "outcome": record["outcome"], "kickoff_utc": record["kickoff_utc"],
            "features": features, "fair": fair,
            "odds": {"1": float(record["odds_home"]), "X": float(record["odds_draw"]), "2": float(record["odds_away"])},
        })
    return rows


def _candidate_rows(conn, now_value):
    capture_floor = stamp(now_value - timedelta(minutes=15))
    sql = _odds_cte(min_capture=True) + """
        SELECT s.* FROM ranked_snapshots s
        LEFT JOIN prediction_inputs i ON i.round_id=s.round_id AND i.fixture_id=s.fixture_id
        LEFT JOIN results r ON r.round_id=s.round_id AND r.fixture_id=s.fixture_id
        WHERE s.sequence_no=1 AND i.id IS NULL
          AND (r.status IS NULL OR r.status!='FINAL')
          AND julianday(s.kickoff_utc)>julianday(?)
        ORDER BY julianday(s.captured_utc),julianday(s.kickoff_utc)
    """
    candidates = []
    for row in conn.execute(sql, (capture_floor, stamp(now_value))):
        if parse_time(row["kickoff_utc"]) > now_value and parse_time(row["captured_utc"]) < parse_time(row["kickoff_utc"]):
            candidates.append(dict(row))
    return candidates


class PredictionService:
    def __init__(self, connect, interval=2.0):
        self.connect = connect
        self.interval = interval
        self.wake = threading.Event()
        self.stopping = threading.Event()
        self.thread = None
        self.backtest_lock = threading.Lock()
        self.backtest_thread = None
        self.backtest_running = False
        self.last_error = None
        self.last_backtest_check = 0.0

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.stopping.clear()
        self.thread = threading.Thread(target=self._loop, name="prediction-worker", daemon=True)
        self.thread.start()

    def stop(self):
        self.stopping.set()
        self.wake.set()
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=3)

    def notify(self):
        self.wake.set()

    def _loop(self):
        while not self.stopping.is_set():
            try:
                self.process_cycle()
                self.last_error = None
            except Exception as exc:
                self.last_error = f"{type(exc).__name__}: {exc}"
                try:
                    with self.connect() as conn:
                        _event(conn, "ERROR", "prediction_worker", self.last_error)
                except Exception:
                    pass
            self.wake.wait(self.interval)
            self.wake.clear()

    def process_cycle(self):
        self.settle_pending()
        self.process_predictions()
        self._maybe_backtest()

    def process_predictions(self):
        now_value = now_utc()
        with self.connect() as conn:
            candidates = _candidate_rows(conn, now_value)
            active_models = [row["model_id"] for row in conn.execute("SELECT model_id FROM model_registry WHERE status IN ('BASELINE','CANDIDATE','QUALIFIED') ORDER BY model_id")]
        if not candidates:
            return 0
        by_capture = {}
        for item in candidates:
            by_capture.setdefault(item["captured_utc"], []).append(item)
        created = 0
        for cutoff, group in by_capture.items():
            with self.connect() as conn:
                training = completed_dataset(conn, cutoff)
            targets = []
            usable = []
            for item in group:
                try:
                    fair, features = odds_features(item["odds_home"], item["odds_draw"], item["odds_away"])
                    item["fair"] = fair
                    item["features"] = features
                    targets.append(item)
                    usable.append(item)
                except (TypeError, ValueError, ZeroDivisionError):
                    continue
            if not usable:
                continue
            predicted_utc = stamp()
            outputs = {}
            for model_id in active_models:
                outputs[model_id] = predict_many(model_id, training, usable)
            with self.connect() as conn:
                conn.execute("BEGIN IMMEDIATE")
                try:
                    current_settings = _settings(conn)
                    statuses = {r["model_id"]: r["status"] for r in conn.execute("SELECT model_id,status FROM model_registry")}
                    for item_index, item in enumerate(usable):
                        if parse_time(predicted_utc) >= parse_time(item["kickoff_utc"]):
                            continue
                        result = conn.execute("SELECT status FROM results WHERE round_id=? AND fixture_id=?",
                                              (item["round_id"], item["fixture_id"])).fetchone()
                        if result and result["status"] == "FINAL":
                            continue
                        source = f"{item['round_id']}|{item['fixture_id']}|{cutoff}|{item['odds_home']}|{item['odds_draw']}|{item['odds_away']}"
                        source_hash = hashlib.sha256(source.encode()).hexdigest()
                        cursor = conn.execute("""
                            INSERT OR IGNORE INTO prediction_inputs
                            (round_id,fixture_id,competition_id,competition,fixture,locked_captured_utc,kickoff_utc,
                             odds_home,odds_draw,odds_away,features_json,source_hash,created_utc)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                        """, (item["round_id"], item["fixture_id"], item["competition_id"], item["competition"],
                              item["fixture"], cutoff, item["kickoff_utc"], item["odds_home"], item["odds_draw"],
                              item["odds_away"], json.dumps(item["features"]), source_hash, predicted_utc))
                        if cursor.rowcount == 0:
                            continue
                        input_id = cursor.lastrowid
                        selected_predictions = {}
                        for model_id in active_models:
                            probs, status = outputs[model_id]
                            probabilities = probs[item_index]
                            model = conn.execute("SELECT version FROM model_registry WHERE model_id=?", (model_id,)).fetchone()
                            selection = None
                            if probabilities is not None:
                                probabilities = [float(x) for x in probabilities]
                                selection = CLASSES[max(range(3), key=lambda index: probabilities[index])]
                            conn.execute("""
                                INSERT OR IGNORE INTO predictions
                                (input_id,model_id,model_version,predicted_utc,training_observations,status,predicted_selection,probabilities_json)
                                VALUES(?,?,?,?,?,?,?,?)
                            """, (input_id, model_id, model["version"], predicted_utc, len(training), status,
                                  selection, json.dumps(probabilities) if probabilities is not None else None))
                            pred = conn.execute("SELECT id,probabilities_json,predicted_selection,status FROM predictions WHERE input_id=? AND model_id=?",
                                                (input_id, model_id)).fetchone()
                            if pred:
                                selected_predictions[model_id] = pred
                        self._maybe_place_bet(conn, input_id, item, selected_predictions, statuses, current_settings, predicted_utc)
                        created += 1
                    conn.commit()
                except Exception:
                    conn.rollback()
                    raise
        if created:
            with self.connect() as conn:
                _event(conn, "INFO", "prediction", f"Locked {created} fixture inputs and recorded model predictions before kickoff.")
        return created

    def _maybe_place_bet(self, conn, input_id, item, predictions, statuses, settings, placed_utc):
        if not settings.get("auto_paper_bets"):
            return
        model_id = settings["active_model"]
        prediction = predictions.get(model_id)
        if not prediction or prediction["status"] != "READY" or not prediction["probabilities_json"]:
            return
        model_status = statuses.get(model_id, "CANDIDATE")
        if model_status in ("RETIRED", "UNDERPERFORMING") or (model_status == "CANDIDATE" and not settings.get("allow_unqualified_paper")):
            return
        probabilities = json.loads(prediction["probabilities_json"])
        selection = prediction["predicted_selection"]
        confidence = probabilities[CLASSES.index(selection)]
        if confidence < float(settings["minimum_probability"]):
            return
        stake = min(float(settings["stake"]), float(settings["maximum_stake"]))
        max_exposure = float(settings["maximum_round_exposure"])
        current_exposure = conn.execute("SELECT COALESCE(SUM(stake),0) FROM paper_bets WHERE round_id=?", (item["round_id"],)).fetchone()[0]
        if stake <= 0 or current_exposure + stake > max_exposure:
            return
        balance = float(settings["starting_bankroll"]) + conn.execute("SELECT COALESCE(SUM(amount),0) FROM paper_ledger").fetchone()[0]
        topup = float(settings["topup_amount"])
        if balance < stake and settings.get("automatic_topups") and topup > 0:
            while balance < stake:
                conn.execute("""
                    INSERT INTO paper_ledger(created_utc,transaction_type,amount,reference_key,note)
                    VALUES(?,?,?,?,?)
                """, (placed_utc, "TOP_UP", topup, f"topup:{item['round_id']}:{item['fixture_id']}:{int(balance * 100)}",
                      "Automatic virtual bankroll top-up; not betting profit."))
                balance += topup
        if balance < stake:
            return
        odds = {"1": item["odds_home"], "X": item["odds_draw"], "2": item["odds_away"]}[selection]
        cursor = conn.execute("""
            INSERT OR IGNORE INTO paper_bets
            (input_id,prediction_id,round_id,fixture_id,model_id,model_version,market,selection,
             locked_captured_utc,odds,confidence,stake,status,placed_utc)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (input_id, prediction["id"], item["round_id"], item["fixture_id"], model_id,
              MODEL_INFO[model_id][1], "1X2 - FT", selection, item["captured_utc"], odds,
              confidence, stake, "PENDING", placed_utc))
        if cursor.rowcount == 0:
            return
        bet_id = cursor.lastrowid
        conn.execute("INSERT INTO paper_ledger(created_utc,transaction_type,amount,bet_id,reference_key,note) VALUES(?,?,?,?,?,?)",
                     (placed_utc, "STAKE", -stake, bet_id, f"bet:{bet_id}:stake", "Fixed-stake 1X2 paper bet."))

    def settle_pending(self):
        settled = 0
        with self.connect() as conn:
            scores = conn.execute("""
                SELECT p.id AS prediction_id,p.predicted_selection,p.probabilities_json,r.ft_home,r.ft_away
                FROM predictions p JOIN prediction_inputs i ON i.id=p.input_id
                JOIN results r ON r.round_id=i.round_id AND r.fixture_id=i.fixture_id
                LEFT JOIN prediction_scores s ON s.prediction_id=p.id
                WHERE s.prediction_id IS NULL AND p.probabilities_json IS NOT NULL
                  AND r.status='FINAL' AND r.ft_home IS NOT NULL AND r.ft_away IS NOT NULL
            """).fetchall()
            rows = conn.execute("""
                SELECT b.id AS bet_id,b.stake,b.odds,b.selection,b.status AS bet_status,
                       p.id AS prediction_id,p.probabilities_json,p.predicted_selection,
                       r.ft_home,r.ft_away
                FROM paper_bets b JOIN predictions p ON p.id=b.prediction_id
                JOIN prediction_inputs i ON i.id=b.input_id
                JOIN results r ON r.round_id=i.round_id AND r.fixture_id=i.fixture_id
                WHERE b.status='PENDING' AND r.status='FINAL'
                  AND r.ft_home IS NOT NULL AND r.ft_away IS NOT NULL
            """).fetchall()
            if not rows and not scores:
                return 0
            conn.execute("BEGIN IMMEDIATE")
            try:
                settings = _settings(conn)
                for score in scores:
                    actual = "1" if score["ft_home"] > score["ft_away"] else "2" if score["ft_home"] < score["ft_away"] else "X"
                    loss, brier = _probability_losses(score["probabilities_json"], actual)
                    conn.execute("INSERT OR IGNORE INTO prediction_scores(prediction_id,actual_outcome,scored_utc,correct,log_loss,brier_score) VALUES(?,?,?,?,?,?)",
                                 (score["prediction_id"], actual, stamp(), int(score["predicted_selection"] == actual), loss, brier))
                for row in rows:
                    actual = "1" if row["ft_home"] > row["ft_away"] else "2" if row["ft_home"] < row["ft_away"] else "X"
                    fresh = conn.execute("SELECT status FROM paper_bets WHERE id=?", (row["bet_id"],)).fetchone()
                    if not fresh or fresh["status"] != "PENDING":
                        continue
                    won = actual == row["selection"]
                    payout = float(row["stake"]) * float(row["odds"]) if won else 0.0
                    profit = payout - float(row["stake"])
                    settled_utc = stamp()
                    conn.execute("""
                        INSERT OR IGNORE INTO paper_ledger(created_utc,transaction_type,amount,bet_id,reference_key,note)
                        VALUES(?,?,?,?,?,?)
                    """, (settled_utc, "PAYOUT", payout, row["bet_id"], f"bet:{row['bet_id']}:settlement",
                          f"Settled as {'WIN' if won else 'LOSS'}; outcome {actual}."))
                    conn.execute("UPDATE paper_bets SET status=?,settled_utc=?,actual_outcome=?,gross_payout=?,net_profit=?,bankroll_after=? WHERE id=? AND status='PENDING'",
                                 ("WIN" if won else "LOSS", settled_utc, actual, payout, profit,
                                  _balance(conn, settings), row["bet_id"]))
                    settled += 1
                conn.commit()
            except Exception:
                conn.rollback()
                raise
        if settled or scores:
            with self.connect() as conn:
                _event(conn, "INFO", "settlement", f"Scored {len(scores)} model predictions and settled {settled} paper bets from final full-time scores.")
        return settled

    def start_backtest(self):
        with self.backtest_lock:
            if self.backtest_running:
                return False
            self.backtest_running = True
            self.backtest_thread = threading.Thread(target=self._backtest_entry, name="walk-forward-backtest", daemon=True)
            self.backtest_thread.start()
            return True

    def _backtest_entry(self):
        try:
            self.run_backtest()
        except Exception as exc:
            with self.connect() as conn:
                _event(conn, "ERROR", "backtest", f"{type(exc).__name__}: {exc}")
                conn.execute("UPDATE evaluation_runs SET completed_utc=?,status='ERROR',message=? WHERE status='RUNNING'",
                             (stamp(), f"{type(exc).__name__}: {exc}"[:350]))
        finally:
            with self.backtest_lock:
                self.backtest_running = False

    def run_backtest(self):
        run_id = uuid.uuid4().hex
        started = stamp()
        with self.connect() as conn:
            settings = _settings(conn)
            dataset = completed_dataset(conn, started)
            _event(conn, "INFO", "backtest", f"Started chronological evaluation on {len(dataset)} complete fixtures.")
            conn.execute("INSERT INTO evaluation_runs(id,started_utc,status,message,dataset_size,cutoff_utc) VALUES(?,?,?,?,?,?)",
                         (run_id, started, "RUNNING", "Chronological expanding-window evaluation plus a final untouched period.", len(dataset), started))
            model_rows = [dict(row) for row in conn.execute("SELECT model_id,status FROM model_registry")]
        results = {}
        for model_row in model_rows:
            model_id = model_row["model_id"]
            windows, status = evaluate_chronologically(model_id, dataset, settings)
            results[model_id] = {"windows": windows, "status": status}
        baseline_final = next((w for w in results.get("market_implied", {}).get("windows", []) if w["window"] == "final_untouched"), None)
        for model_id, result in results.items():
            final = next((w for w in result["windows"] if w["window"] == "final_untouched"), None)
            advantage_low = advantage_high = None
            if final and baseline_final and final.get("status") == "EVALUATED" and baseline_final.get("status") == "EVALUATED":
                # Compare final-period per-fixture loss against the same odds baseline.
                split = max(1, int(len(dataset) * 0.8))
                development, test = dataset[:split], dataset[split:]
                model_probs, model_state = predict_many(model_id, development, test)
                base_probs, base_state = predict_many("market_implied", development, test)
                if model_state == "READY" and base_state == "READY":
                    from modeling import loss_advantage_interval
                    advantage_low, advantage_high = loss_advantage_interval([row["outcome"] for row in test], model_probs, base_probs)
            final_n = final.get("test_n", 0) if final else 0
            fold_count = sum(1 for row in result["windows"] if row["window"].startswith("walk_forward_") and row.get("status") == "EVALUATED")
            if model_id == "market_implied":
                qualification = "BENCHMARK"
            elif final_n < int(settings["qualification_min_test"]) or fold_count < 3:
                qualification = "INSUFFICIENT_EVIDENCE"
            elif advantage_low is not None and advantage_low > 0 and (final or {}).get("roi_stake") is not None and final["roi_stake"] > 0 and (final or {}).get("bet_count", 0) >= int(settings["qualification_min_bets"]):
                qualification = "QUALIFIED"
            else:
                qualification = "UNDERPERFORMING"
            result["qualification"] = qualification
            result["advantage_low"] = advantage_low
            result["advantage_high"] = advantage_high
        finished = stamp()
        with self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                for model_id, result in results.items():
                    for window in result["windows"]:
                        conn.execute("""
                            INSERT OR REPLACE INTO evaluation_metrics
                            (run_id,model_id,window_name,training_n,test_n,status,accuracy,accuracy_low,accuracy_high,
                             balanced_accuracy,log_loss,log_loss_low,log_loss_high,brier_score,brier_low,brier_high,
                             confusion_json,calibration_json,bet_count,bet_wins,win_rate,win_rate_low,win_rate_high,
                             profit,roi_stake,roi_stake_low,roi_stake_high,roi_starting_capital,roi_starting_low,
                             roi_starting_high,max_drawdown,max_drawdown_pct,loss_advantage_low,loss_advantage_high,qualification)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                        """, (run_id, model_id, window["window"], window.get("training_n", 0), window.get("test_n", 0),
                              window.get("status", "INSUFFICIENT_HISTORY"), window.get("accuracy"), window.get("accuracy_low"),
                              window.get("accuracy_high"), window.get("balanced_accuracy"), window.get("log_loss"),
                              window.get("log_loss_low"), window.get("log_loss_high"), window.get("brier_score"),
                              window.get("brier_low"), window.get("brier_high"), json.dumps(window.get("confusion")) if window.get("confusion") else None,
                               json.dumps(window.get("calibration")) if window.get("calibration") else None,
                               window.get("bet_count", 0), window.get("bet_wins", 0), window.get("win_rate"),
                               window.get("win_rate_low"), window.get("win_rate_high"), window.get("profit"),
                               window.get("roi_stake"), window.get("roi_stake_low"), window.get("roi_stake_high"),
                               window.get("roi_starting_capital"), window.get("roi_starting_low"), window.get("roi_starting_high"),
                              window.get("max_drawdown"), window.get("max_drawdown_pct"),
                              result.get("advantage_low") if window["window"] == "final_untouched" else None,
                              result.get("advantage_high") if window["window"] == "final_untouched" else None,
                              result["qualification"] if window["window"] == "final_untouched" else "WINDOW"))
                    self._apply_qualification(conn, model_id, result["qualification"], final, finished)
                conn.execute("UPDATE evaluation_runs SET completed_utc=?,status='COMPLETE',message=? WHERE id=?",
                             (finished, f"Evaluated {len(dataset)} complete observations across chronological windows.", run_id))
                _event(conn, "INFO", "backtest", f"Completed evaluation {run_id[:8]} on {len(dataset)} fixtures.")
                conn.commit()
            except Exception:
                conn.rollback()
                raise
        return run_id

    def _apply_qualification(self, conn, model_id, qualification, final, changed_utc):
        row = conn.execute("SELECT status,bad_evaluations FROM model_registry WHERE model_id=?", (model_id,)).fetchone()
        if not row or model_id == "market_implied":
            return
        previous = row["status"]
        next_status = previous
        bad = row["bad_evaluations"]
        if qualification == "QUALIFIED":
            next_status, bad = "QUALIFIED", 0
        elif qualification == "UNDERPERFORMING":
            bad += 1
            next_status = "RETIRED" if previous == "QUALIFIED" and bad >= 2 else "UNDERPERFORMING"
        elif qualification == "INSUFFICIENT_EVIDENCE" and previous not in ("QUALIFIED", "RETIRED"):
            next_status = "CANDIDATE"
        reason = qualification
        if final and final.get("status") == "EVALUATED":
            reason += f"; final test n={final.get('test_n')}, log loss={final.get('log_loss')}, ROI/stake={final.get('roi_stake')}"
        conn.execute("UPDATE model_registry SET status=?,status_reason=?,bad_evaluations=?,updated_utc=? WHERE model_id=?",
                     (next_status, reason[:350], bad, changed_utc, model_id))
        if next_status != previous:
            conn.execute("INSERT INTO model_status_history(model_id,previous_status,new_status,reason,changed_utc) VALUES(?,?,?,?,?)",
                         (model_id, previous, next_status, reason[:350], changed_utc))
            _event(conn, "INFO", "model_status", f"{MODEL_INFO[model_id][0]}: {previous} → {next_status} ({reason[:220]}).")
            if next_status == "RETIRED":
                settings = _settings(conn)
                if settings.get("active_model") == model_id:
                    conn.execute("UPDATE ai_settings SET value_json=?,updated_utc=? WHERE key='active_model'",
                                 (json.dumps("market_implied"), changed_utc))
                    _event(conn, "WARNING", "model_status", "Paper strategy returned to the market-implied baseline after model retirement.")

    def reinstate_model(self, model_id, reason):
        if not reason or len(reason.strip()) < 8:
            raise ValueError("Add a short written reason for reinstatement.")
        with self.connect() as conn:
            model = conn.execute("SELECT status FROM model_registry WHERE model_id=?", (model_id,)).fetchone()
            run = conn.execute("SELECT id FROM evaluation_runs WHERE status='COMPLETE' ORDER BY completed_utc DESC LIMIT 1").fetchone()
            metric = conn.execute("SELECT qualification FROM evaluation_metrics WHERE run_id=? AND model_id=? AND window_name='final_untouched'",
                                  (run["id"], model_id)).fetchone() if run else None
            if not model or model["status"] != "RETIRED":
                raise ValueError("Only a retired model can be reinstated.")
            if not metric or metric["qualification"] != "QUALIFIED":
                raise ValueError("Run a new chronological evaluation that qualifies this model before reinstating it.")
            current = stamp()
            conn.execute("UPDATE model_registry SET status='QUALIFIED',status_reason=?,bad_evaluations=0,updated_utc=? WHERE model_id=?",
                         (f"Reinstated after evaluation {run['id'][:8]}: {reason.strip()}"[:350], current, model_id))
            conn.execute("INSERT INTO model_status_history(model_id,previous_status,new_status,reason,changed_utc) VALUES(?,?,?,?,?)",
                         (model_id, "RETIRED", "QUALIFIED", reason.strip()[:350], current))
            _event(conn, "INFO", "model_status", f"{MODEL_INFO[model_id][0]} reinstated after a documented qualifying evaluation.")

    def save_settings(self, updates):
        with self.connect() as conn:
            current = _settings(conn)
            allowed = {"starting_bankroll", "stake", "maximum_stake", "minimum_probability",
                       "maximum_round_exposure", "topup_amount", "automatic_topups", "auto_paper_bets",
                       "active_model", "allow_unqualified_paper"}
            unknown = set(updates) - allowed
            if unknown:
                raise ValueError(f"Unsupported setting: {sorted(unknown)[0]}")
            proposed = dict(current)
            proposed.update(updates)
            for key in ("starting_bankroll", "stake", "maximum_stake", "maximum_round_exposure", "topup_amount"):
                try:
                    proposed[key] = float(proposed[key])
                except (TypeError, ValueError):
                    raise ValueError(f"{key.replace('_', ' ').title()} must be a number.")
                if not math.isfinite(proposed[key]) or proposed[key] < 0:
                    raise ValueError(f"{key.replace('_', ' ').title()} cannot be negative.")
            proposed["minimum_probability"] = float(proposed["minimum_probability"])
            if not 0 < proposed["minimum_probability"] <= 1:
                raise ValueError("Minimum probability must be above 0 and at most 1.")
            if proposed["starting_bankroll"] <= 0 or proposed["stake"] <= 0 or proposed["maximum_stake"] <= 0:
                raise ValueError("Starting bankroll and stake limits must be greater than 0.")
            if proposed["maximum_round_exposure"] < min(proposed["stake"], proposed["maximum_stake"]):
                raise ValueError("Round exposure must cover at least one configured stake.")
            proposed["automatic_topups"] = bool(proposed["automatic_topups"])
            proposed["auto_paper_bets"] = bool(proposed["auto_paper_bets"])
            proposed["allow_unqualified_paper"] = bool(proposed["allow_unqualified_paper"])
            model = conn.execute("SELECT status FROM model_registry WHERE model_id=?", (proposed["active_model"],)).fetchone()
            if not model or model["status"] in ("RETIRED", "UNDERPERFORMING"):
                raise ValueError("Choose a model that is available for paper trading.")
            if model["status"] == "CANDIDATE" and not proposed["allow_unqualified_paper"]:
                raise ValueError("Enable unqualified candidate paper bets before selecting this model.")
            has_bets = conn.execute("SELECT 1 FROM paper_bets LIMIT 1").fetchone()
            if has_bets and proposed["starting_bankroll"] != current["starting_bankroll"]:
                raise ValueError("Starting bankroll is fixed after the first paper bet; use separate top-up settings thereafter.")
            current_utc = stamp()
            conn.execute("BEGIN IMMEDIATE")
            try:
                for key, value in proposed.items():
                    conn.execute("INSERT INTO ai_settings(key,value_json,updated_utc) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,updated_utc=excluded.updated_utc",
                                 (key, json.dumps(value), current_utc))
                _event(conn, "INFO", "settings", "Paper account settings updated.")
                conn.commit()
            except Exception:
                conn.rollback()
                raise
        self.notify()
        return proposed

    def _maybe_backtest(self):
        if time.monotonic() - self.last_backtest_check < 60:
            return
        self.last_backtest_check = time.monotonic()
        with self.connect() as conn:
            count = len(completed_dataset(conn))
            latest = conn.execute("SELECT dataset_size,completed_utc FROM evaluation_runs WHERE status='COMPLETE' ORDER BY completed_utc DESC LIMIT 1").fetchone()
        if count < 80:
            return
        stale_by_size = not latest or count - latest["dataset_size"] >= 100
        stale_by_time = not latest or (now_utc() - parse_time(latest["completed_utc"])).total_seconds() >= 86400
        if stale_by_size or stale_by_time:
            self.start_backtest()

    def state(self):
        with self.connect() as conn:
            settings = _settings(conn)
            dataset = completed_dataset(conn)
            latest_run = conn.execute("SELECT * FROM evaluation_runs ORDER BY started_utc DESC LIMIT 1").fetchone()
            model_rows = [dict(row) for row in conn.execute("SELECT * FROM model_registry ORDER BY CASE status WHEN 'BASELINE' THEN 0 WHEN 'QUALIFIED' THEN 1 WHEN 'CANDIDATE' THEN 2 WHEN 'UNDERPERFORMING' THEN 3 ELSE 4 END,name")]
            if latest_run:
                out_of_sample = conn.execute("SELECT COALESCE(MAX(test_n),0) FROM evaluation_metrics WHERE run_id=? AND window_name='final_untouched'", (latest_run["id"],)).fetchone()[0]
                for model in model_rows:
                    metric = conn.execute("SELECT * FROM evaluation_metrics WHERE run_id=? AND model_id=? AND window_name='final_untouched'",
                                          (latest_run["id"], model["model_id"])).fetchone()
                    model["latest_evaluation"] = dict(metric) if metric else None
            else:
                out_of_sample = 0
                for model in model_rows:
                    model["latest_evaluation"] = None
            scored = conn.execute("SELECT COUNT(*) AS n,COALESCE(AVG(correct),0) AS accuracy FROM prediction_scores").fetchone()
            live_models = {row["model_id"]: dict(row) for row in conn.execute("""
                SELECT p.model_id,COUNT(s.prediction_id) AS n,SUM(s.correct) AS correct,AVG(s.correct) AS accuracy,
                       AVG(s.log_loss) AS log_loss,AVG(s.brier_score) AS brier_score
                FROM predictions p LEFT JOIN prediction_scores s ON s.prediction_id=p.id
                GROUP BY p.model_id
            """)}
            for model in model_rows:
                model["live_metrics"] = live_models.get(model["model_id"],
                    {"n": 0, "correct": 0, "accuracy": None, "log_loss": None, "brier_score": None})
                live = model["live_metrics"]
                live["accuracy_low"], live["accuracy_high"] = _wilson(live["correct"] or 0, live["n"] or 0)
                model["current_training_n"] = len(dataset)
            counts = {
                "rounds": conn.execute("SELECT COUNT(DISTINCT round_id) FROM odds").fetchone()[0],
                "odds": conn.execute("SELECT COUNT(*) FROM odds").fetchone()[0],
                "predictions": conn.execute("SELECT COUNT(*) FROM predictions WHERE status='READY'").fetchone()[0],
                "usable": len(dataset), "training_observations": len(dataset),
                "out_of_sample": out_of_sample,
                "pending_bets": conn.execute("SELECT COUNT(*) FROM paper_bets WHERE status='PENDING'").fetchone()[0],
                "duplicate_odds": conn.execute("SELECT COUNT(*) FROM (SELECT round_id,fixture_id,captured_utc,market,selection FROM odds GROUP BY round_id,fixture_id,captured_utc,market,selection HAVING COUNT(*)>1)").fetchone()[0],
                "awaiting_results": conn.execute("SELECT COUNT(*) FROM results WHERE status!='FINAL'").fetchone()[0],
            }
            ledger = [dict(row) for row in conn.execute("SELECT created_utc,transaction_type,amount,bet_id,note FROM paper_ledger ORDER BY id DESC LIMIT 40")]
            bets = [dict(row) for row in conn.execute("""
                SELECT b.id,b.placed_utc,b.settled_utc,i.competition,i.fixture,b.round_id,b.market,b.selection,
                       b.odds,b.confidence,b.model_id,b.stake,b.status,b.actual_outcome,b.gross_payout,b.net_profit,b.bankroll_after
                FROM paper_bets b JOIN prediction_inputs i ON i.id=b.input_id
                ORDER BY b.id DESC LIMIT 80
            """).fetchall()]
            recent_predictions = [dict(row) for row in conn.execute("""
                SELECT p.id,p.predicted_utc,p.model_id,p.model_version,p.training_observations,p.status,
                       p.predicted_selection,p.probabilities_json,i.round_id,i.fixture_id,i.competition,i.fixture,
                       i.locked_captured_utc,i.kickoff_utc,i.odds_home,i.odds_draw,i.odds_away
                FROM predictions p JOIN prediction_inputs i ON i.id=p.input_id
                WHERE i.locked_captured_utc=(SELECT MAX(locked_captured_utc) FROM prediction_inputs)
                ORDER BY i.competition,i.fixture,p.model_id LIMIT 180
            """).fetchall()]
            for prediction in recent_predictions:
                prediction["probabilities"] = json.loads(prediction.pop("probabilities_json")) if prediction["probabilities_json"] else None
            start_capital = float(settings["starting_bankroll"])
            ledger_delta = conn.execute("SELECT COALESCE(SUM(amount),0) FROM paper_ledger").fetchone()[0]
            topups = conn.execute("SELECT COALESCE(SUM(amount),0) FROM paper_ledger WHERE transaction_type='TOP_UP'").fetchone()[0]
            stakes = conn.execute("SELECT COALESCE(SUM(stake),0) FROM paper_bets").fetchone()[0]
            payouts = conn.execute("SELECT COALESCE(SUM(gross_payout),0) FROM paper_bets").fetchone()[0]
            profit = conn.execute("SELECT COALESCE(SUM(net_profit),0) FROM paper_bets WHERE status IN ('WIN','LOSS')").fetchone()[0]
            settled_bets = conn.execute("SELECT COUNT(*) AS n,COALESCE(SUM(status='WIN'),0) AS wins FROM paper_bets WHERE status IN ('WIN','LOSS')").fetchone()
            unit_returns = [float(row["net_profit"]) / float(row["stake"]) for row in conn.execute("SELECT net_profit,stake FROM paper_bets WHERE status IN ('WIN','LOSS') AND stake>0")]
            roi_low, roi_high = _mean_interval(unit_returns, seed=19)
            win_rate_low, win_rate_high = _wilson(settled_bets["wins"], settled_bets["n"])
            bankroll = start_capital + ledger_delta
            daily_weekly = {}
            for label, days in (("day", 1), ("week", 7)):
                since = stamp(now_utc() - timedelta(days=days))
                daily_weekly[label] = conn.execute("SELECT COALESCE(SUM(net_profit),0) FROM paper_bets WHERE status IN ('WIN','LOSS') AND julianday(settled_utc)>=julianday(?)", (since,)).fetchone()[0]
            drawdown = self._live_drawdown(conn, start_capital)
            last_collection = conn.execute("SELECT captured_utc,status,message,round_id,matchday FROM collection_log ORDER BY id DESC LIMIT 1").fetchone()
            delayed = [dict(row) for row in conn.execute("""
                SELECT b.id,i.fixture,b.round_id,i.kickoff_utc,b.placed_utc
                FROM paper_bets b JOIN prediction_inputs i ON i.id=b.input_id
                WHERE b.status='PENDING' AND julianday(i.kickoff_utc)<julianday(?)
                ORDER BY i.kickoff_utc LIMIT 30
            """, (stamp(now_utc() - timedelta(minutes=10)),))]
            events = [dict(row) for row in conn.execute("SELECT created_utc,severity,category,message FROM ai_events ORDER BY id DESC LIMIT 20")]
            evaluation_windows = []
            if latest_run:
                evaluation_windows = [dict(row) for row in conn.execute("""
                    SELECT m.model_id,m.window_name,m.training_n,m.test_n,m.status,m.accuracy,m.balanced_accuracy,
                           m.log_loss,m.brier_score,m.bet_count,m.profit,m.roi_stake,m.roi_stake_low,m.roi_stake_high,
                           m.max_drawdown,m.qualification
                    FROM evaluation_metrics m WHERE m.run_id=? ORDER BY m.window_name,m.model_id
                """, (latest_run["id"],))]
            duplicate_results = conn.execute("SELECT COUNT(*) FROM (SELECT round_id,fixture_id FROM results GROUP BY round_id,fixture_id HAVING COUNT(*)>1)").fetchone()[0]
        precision_goal = max(0, math.ceil((1.959963984540054 ** 2) * 0.25 / (0.05 ** 2)) - len(dataset))
        return {
            "settings": settings,
            "ml_available": importlib.util.find_spec("sklearn") is not None,
            "collector": {"last_run": dict(last_collection) if last_collection else None},
            "counts": counts | {"duplicate_results": duplicate_results},
            "models": model_rows,
            "live": {"scored_predictions": scored["n"], "accuracy": scored["accuracy"],
                     "active_models": sum(1 for row in model_rows if row["status"] in ("BASELINE", "QUALIFIED", "CANDIDATE")),
                     "latest_predictions": recent_predictions},
            "account": {"starting_bankroll": start_capital, "topups": topups, "total_stakes": stakes,
                        "gross_payouts": payouts, "profit": profit, "bankroll": bankroll,
                        "return_starting": profit / start_capital if start_capital else None,
                        "return_contributed": profit / (start_capital + topups) if start_capital + topups else None,
                        "return_on_stake": profit / stakes if stakes else None,
                        "return_on_stake_low": roi_low, "return_on_stake_high": roi_high,
                        "wins": settled_bets["wins"], "settled": settled_bets["n"],
                        "win_rate": settled_bets["wins"] / settled_bets["n"] if settled_bets["n"] else None,
                        "win_rate_low": win_rate_low, "win_rate_high": win_rate_high,
                        "max_drawdown": drawdown, "pending": counts["pending_bets"],
                        "daily_profit": daily_weekly["day"], "weekly_profit": daily_weekly["week"]},
            "bets": bets, "ledger": ledger, "delayed": delayed,
            "quality": {"complete_observations": len(dataset), "additional_for_approx_5pct_accuracy_margin": precision_goal,
                        "randomness": randomness_summary(dataset), "note": "The precision estimate assumes independent Bernoulli observations and is only a rough planning guide."},
            "evaluation": {"running": self.backtest_running, "last_run": dict(latest_run) if latest_run else None,
                           "windows": evaluation_windows},
            "events": events, "worker_error": self.last_error,
        }

    def _live_drawdown(self, conn, start_capital):
        rows = conn.execute("SELECT net_profit FROM paper_bets WHERE status IN ('WIN','LOSS') ORDER BY settled_utc,id").fetchall()
        profit = peak = drawdown = 0.0
        for row in rows:
            profit += float(row["net_profit"] or 0)
            peak = max(peak, profit)
            drawdown = max(drawdown, peak - profit)
        return drawdown


def _probability_losses(probabilities_json, actual):
    try:
        values = json.loads(probabilities_json)
        index = CLASSES.index(actual)
        loss = -math.log(max(1e-12, float(values[index])))
        brier = sum((float(values[i]) - (1 if i == index else 0)) ** 2 for i in range(3))
        return loss, brier
    except (TypeError, ValueError, IndexError, json.JSONDecodeError):
        return -math.log(1 / 3), 2 / 3


def _balance(conn, settings):
    return float(settings["starting_bankroll"]) + conn.execute("SELECT COALESCE(SUM(amount),0) FROM paper_ledger").fetchone()[0]
