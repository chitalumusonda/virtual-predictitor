from contextlib import contextmanager
import json
import sqlite3
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from modeling import CLASSES, evaluate_chronologically, loss_advantage_interval, odds_features
from prediction_engine import (
    DEFAULT_SETTINGS,
    PredictionService,
    completed_dataset,
    initialize_ai_schema,
)


BASE_SCHEMA = """
CREATE TABLE odds (
 id INTEGER PRIMARY KEY,captured_utc TEXT NOT NULL,season_id TEXT NOT NULL,matchday INTEGER NOT NULL,
 round_id TEXT NOT NULL,fixture_id TEXT NOT NULL,competition_id TEXT NOT NULL,competition TEXT NOT NULL,
 fixture TEXT NOT NULL,home TEXT NOT NULL,away TEXT NOT NULL,market TEXT NOT NULL,selection TEXT NOT NULL,
 odds REAL NOT NULL,probability REAL,kickoff_utc TEXT,UNIQUE(captured_utc,round_id,fixture_id,market,selection)
);
CREATE TABLE results (
 season_id TEXT NOT NULL,matchday INTEGER NOT NULL,round_id TEXT NOT NULL,fixture_id TEXT NOT NULL,
 competition_id TEXT NOT NULL,competition TEXT NOT NULL,fixture TEXT NOT NULL,home TEXT NOT NULL,away TEXT NOT NULL,
 ht_home INTEGER,ht_away INTEGER,ft_home INTEGER,ft_away INTEGER,outcome TEXT,total_goals INTEGER,btts TEXT,
 minute INTEGER,status TEXT NOT NULL,updated_utc TEXT NOT NULL,PRIMARY KEY(round_id,fixture_id)
);
CREATE TABLE collection_log (
 id INTEGER PRIMARY KEY,captured_utc TEXT NOT NULL,season_id TEXT,matchday INTEGER,round_id TEXT,
 odds_rows INTEGER NOT NULL DEFAULT 0,result_rows INTEGER NOT NULL DEFAULT 0,bytes_received INTEGER NOT NULL DEFAULT 0,
 status TEXT NOT NULL,message TEXT NOT NULL
);
"""


class PredictionEngineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "test.sqlite3"
        with self.connection() as conn:
            conn.executescript(BASE_SCHEMA)
            initialize_ai_schema(conn)
        self.service = PredictionService(self.connection, interval=0.05)

    def tearDown(self):
        self.service.stop()
        self.temp.cleanup()

    def connect(self):
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    @contextmanager
    def connection(self):
        conn = self.connect()
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def add_fixture(self, index, captured, kickoff, result=None, odds=(1.5, 4.0, 6.0), round_id=None):
        round_id = round_id or f"round-{index}"
        fixture_id = f"fixture-{index}"
        captured = captured.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
        kickoff = kickoff.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
        home, draw, away = odds
        for selection, price in zip(CLASSES, (home, draw, away)):
            with self.connection() as conn:
                conn.execute("""
                    INSERT INTO odds(captured_utc,season_id,matchday,round_id,fixture_id,competition_id,competition,
                                     fixture,home,away,market,selection,odds,kickoff_utc)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (captured, "season", index, round_id, fixture_id, "7794", "English League",
                      f"H{index} - A{index}", f"H{index}", f"A{index}", "1X2", selection, price, kickoff))
        if result is not None:
            ft_home, ft_away, updated = result
            outcome = "1" if ft_home > ft_away else "2" if ft_home < ft_away else "X"
            with self.connection() as conn:
                conn.execute("""
                    INSERT INTO results(season_id,matchday,round_id,fixture_id,competition_id,competition,fixture,
                                        home,away,ht_home,ht_away,ft_home,ft_away,outcome,total_goals,btts,minute,status,updated_utc)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, ("season", index, round_id, fixture_id, "7794", "English League", f"H{index} - A{index}",
                      f"H{index}", f"A{index}", 0, 0, ft_home, ft_away, outcome, ft_home + ft_away,
                      "Yes" if ft_home and ft_away else "No", 90, "FINAL",
                      updated.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")))
        return round_id, fixture_id

    def test_training_cutoff_excludes_results_not_known_yet(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        self.add_fixture(1, base, base + timedelta(minutes=2), (2, 0, base + timedelta(minutes=7)))
        self.add_fixture(2, base + timedelta(minutes=10), base + timedelta(minutes=12), (0, 1, base + timedelta(minutes=20)))
        with self.connection() as conn:
            early = completed_dataset(conn, "2026-01-01T00:10:00.000Z")
            later = completed_dataset(conn, "2026-01-01T00:30:00.000Z")
        self.assertEqual(len(early), 1)
        self.assertEqual(len(later), 2)

    def test_prediction_input_is_locked_once_and_incomplete_prices_are_ignored(self):
        now = datetime.now(timezone.utc)
        future = now + timedelta(minutes=4)
        captured = now - timedelta(seconds=1)
        round_id, fixture_id = "live-round", "live-fixture"
        with self.connection() as conn:
            conn.execute("""
                INSERT INTO odds(captured_utc,season_id,matchday,round_id,fixture_id,competition_id,competition,
                                 fixture,home,away,market,selection,odds,kickoff_utc)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (captured.isoformat(timespec="milliseconds").replace("+00:00", "Z"), "s", 1,
                  round_id, fixture_id, "7794", "English", "H - A", "H", "A", "1X2", "1", 1.5,
                  future.isoformat(timespec="seconds").replace("+00:00", "Z")))
        self.assertEqual(self.service.process_predictions(), 0)
        self.add_fixture(3, captured, future, None, round_id=round_id)
        # The helper adds a second fixture ID; the original incomplete record remains ineligible.
        self.assertEqual(self.service.process_predictions(), 1)
        self.assertEqual(self.service.process_predictions(), 0)
        with self.connection() as conn:
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM prediction_inputs").fetchone()[0], 1)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM predictions").fetchone()[0], 6)

    def test_paper_bet_topup_settlement_and_restart_are_idempotent(self):
        now = datetime.now(timezone.utc)
        with self.connection() as conn:
            updates = {key: value for key, value in DEFAULT_SETTINGS.items()
                       if key not in ("qualification_min_test", "qualification_min_bets")}
            updates.update({"starting_bankroll": 5, "stake": 10, "maximum_stake": 10,
                            "minimum_probability": 0.4, "maximum_round_exposure": 50,
                            "topup_amount": 20, "auto_paper_bets": True})
        self.service.save_settings(updates)
        round_id, fixture_id = self.add_fixture(4, now - timedelta(seconds=2), now + timedelta(minutes=3), None,
                                                odds=(1.5, 5.0, 8.0), round_id="paper-round")
        self.assertEqual(self.service.process_predictions(), 1)
        self.assertEqual(self.service.process_predictions(), 0)
        with self.connection() as conn:
            bet = conn.execute("SELECT * FROM paper_bets").fetchone()
            self.assertIsNotNone(bet)
            self.assertEqual(bet["status"], "PENDING")
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM paper_ledger WHERE transaction_type='TOP_UP'").fetchone()[0], 1)
            self.assertAlmostEqual(conn.execute("SELECT SUM(amount) FROM paper_ledger").fetchone()[0], 10.0)
            conn.execute("""
                INSERT INTO results(season_id,matchday,round_id,fixture_id,competition_id,competition,fixture,
                                    home,away,ht_home,ht_away,ft_home,ft_away,outcome,total_goals,btts,minute,status,updated_utc)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, ("season", 4, round_id, fixture_id, "7794", "English League", "H4 - A4", "H4", "A4",
                  0, 0, 1, 0, "1", 1, "No", 90, "FINAL",
                  (now + timedelta(minutes=4)).isoformat(timespec="milliseconds").replace("+00:00", "Z")))
        self.assertEqual(self.service.settle_pending(), 1)
        self.assertEqual(self.service.settle_pending(), 0)
        restarted = PredictionService(self.connection)
        state = restarted.state()
        self.assertEqual(state["account"]["pending"], 0)
        self.assertAlmostEqual(state["account"]["profit"], 5.0)
        self.assertAlmostEqual(state["account"]["bankroll"], 30.0)
        with self.connection() as conn:
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM paper_ledger WHERE transaction_type='PAYOUT'").fetchone()[0], 1)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM prediction_scores").fetchone()[0], 2)

    def test_chronological_backtest_keeps_final_period_later(self):
        dataset = []
        base = datetime(2025, 1, 1, tzinfo=timezone.utc)
        for index in range(150):
            odds = (1.8 + index % 4 * 0.1, 3.5 + index % 3 * 0.1, 4.4 + index % 5 * 0.1)
            fair, features = odds_features(*odds)
            dataset.append({"round_id": f"r{index}", "fixture_id": f"f{index}",
                            "kickoff_utc": (base + timedelta(minutes=index * 5)).isoformat(),
                            "features": features, "fair": fair, "odds": dict(zip(CLASSES, odds)),
                            "outcome": CLASSES[index % 3]})
        windows, status = evaluate_chronologically("market_implied", dataset, DEFAULT_SETTINGS)
        self.assertEqual(status, "EVALUATED")
        self.assertGreaterEqual(sum(row["window"].startswith("walk_forward_") for row in windows), 3)
        final = next(row for row in windows if row["window"] == "final_untouched")
        self.assertGreater(final["training_n"], final["test_n"])
        self.assertEqual(final["test_n"], 30)

    def test_backtest_persists_final_period_diagnostics(self):
        base = datetime(2025, 1, 1, tzinfo=timezone.utc)
        for index in range(150):
            kickoff = base + timedelta(minutes=index * 10 + 5)
            score = (2, 0) if index % 3 == 0 else (1, 1) if index % 3 == 1 else (0, 1)
            self.add_fixture(index, kickoff - timedelta(minutes=5), kickoff,
                             (*score, kickoff + timedelta(minutes=4)))
        run_id = self.service.run_backtest()
        state = self.service.state()
        self.assertEqual(state["evaluation"]["last_run"]["id"], run_id)
        self.assertEqual(state["evaluation"]["last_run"]["status"], "COMPLETE")
        baseline = next(model for model in state["models"] if model["model_id"] == "market_implied")
        final = baseline["latest_evaluation"]
        self.assertEqual(final["test_n"], 30)
        confusion = json.loads(final["confusion_json"])
        self.assertEqual(sum(sum(row.values()) for row in confusion.values()), 30)
        self.assertTrue(json.loads(final["calibration_json"]))

    def test_loss_comparison_and_precision_bounds(self):
        actual = ["1", "X", "2"]
        probabilities = [[0.7, 0.2, 0.1], [0.2, 0.6, 0.2], [0.1, 0.2, 0.7]]
        low, high = loss_advantage_interval(actual, probabilities, probabilities, repeats=100)
        self.assertAlmostEqual(low, 0)
        self.assertAlmostEqual(high, 0)


if __name__ == "__main__":
    unittest.main()
